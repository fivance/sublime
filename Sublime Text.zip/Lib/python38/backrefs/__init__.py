"""Backrefs package."""
from .__meta__ import __version__, __version_info__  # noqa: F401
