"""Lch color class."""
