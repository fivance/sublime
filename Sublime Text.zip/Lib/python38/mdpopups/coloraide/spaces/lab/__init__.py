"""Lab color class."""
