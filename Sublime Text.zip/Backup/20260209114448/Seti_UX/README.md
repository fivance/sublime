<h1 align="center" style="border: none">
    Seti_UX
    <br>
    <a href="https://packagecontrol.io/packages/Seti_UX/"><img src="https://img.shields.io/packagecontrol/dt/Seti_UX.svg" alt="Packagecontrol total downloads" /></a>
</h1>

Seti Improved Scheme/Syntax-HL for ST.

## Ports

* [JetBrains](https://github.com/zchee/Seti_JetBrains) thanks to [@zchee](https://github.com/zchee)
* [iTerm](https://github.com/ginfuru/iTerm-Seti_UX) thanks to [@ginfuru](https://github.com/ginfuru)
* [Terminal](https://github.com/ginfuru/iTerm-Seti_UX) thanks to [@ginfuru](https://github.com/ginfuru)
* [HyperTerminal](https://github.com/ginfuru/iTerm-Seti_UX) thanks to [@ginfuru](https://github.com/ginfuru)

## Previews

**HTML**

![Seti Screenshot](./ss/html.jpg)

**PHP**

![Seti Screenshot](./ss/php.jpg)

**JS**

![Seti Screenshot](./ss/js.jpg)
